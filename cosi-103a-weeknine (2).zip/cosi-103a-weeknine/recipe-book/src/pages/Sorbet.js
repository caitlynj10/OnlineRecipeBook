import React, { useState, useEffect} from 'react';
import './recipes.css';
import {useNavigate} from 'react-router-dom';

export default function Sorbet() {
    return (
     <>
    <RecipeDetails/>
    </>
    );
  
    }

  function RecipeDetails(){
    const [checkedItems, setCheckedItems] = useState([]);
      const navigate = useNavigate();

      const handleCheckbox = (event) => {
       const {name, checked} = event.target;

       setIngredients(ingredients =>
        ingredients.map(ingredient =>
          ingredient.name === name ? { ...ingredient, checked: checked } : ingredient
        )
      );

       setCheckedItems((prev) => {
          if(checked){
            return [...prev, name];
          }
          else{
            return prev.filter((item) => item !== name);
          }
        });
      };

      const goToGroceryList = () => {
        const savedItems = localStorage.getItem('items');
        const allItems = savedItems ? [...JSON.parse(savedItems), ...checkedItems] : checkedItems;  
        localStorage.setItem('items', JSON.stringify(allItems));
        navigate('../GroceryList');

      }

      
      const [isOpen, setIsOpen] = useState(false);
      const togglePopup = () => {
        setIsOpen(!isOpen);
      }
      const [ingredients, setIngredients] = useState([
        {name: "16 oz Frozen Mango Chunks", fullName: "1 package (16 ounces) frozen mango chunks, slightly thawed", checked: false, id: 0},
        {name: "Passion Fruit Juice", fullName: "1/2 cup passion fruit juice", checked: false, id: 0},
        {name: "Sugar", fullName: "2 tablespoons sugar", checked: false, id: 0}
      ]);
    
      useEffect(() => {
        const updateIngredientIds = async () => {
          const apiKey = process.env.REACT_APP_API_KEY; // Moved inside the function for clarity
          console.log(apiKey);
          const updatedIngredients = await Promise.all(ingredients.map(async (ingredient) => {
            const baseUrl = `https://api.nal.usda.gov/fdc/v1/foods/search?api_key=${apiKey}`;
            const queryUrl = `${baseUrl}&query=${encodeURIComponent(ingredient.name)}`;
    
            try {
              const response = await fetch(queryUrl);
              if (!response.ok) {
                throw new Error(`API call failed: ${response.status}`);
              }
              const data = await response.json();
              if (data.foods && data.foods.length > 0) {
                const id = data.foods[0].fdcId;
                return { ...ingredient, id }; // Return a new ingredient object with the updated ID
              } else {
                console.log(`No results found for ${ingredient.name}`);
                return ingredient; // Return the original ingredient if no ID is found
              }
            } catch (error) {
              console.error(`Failed to fetch ID for ${ingredient.name}:`, error);
              return ingredient; // Return the original ingredient in case of error
            }
          }));
    
          setIngredients(updatedIngredients); // Update the state once with all updated ingredients
        };
    
        updateIngredientIds();
        // Removed ingredients from the dependency array to prevent re-triggering
      }, [ingredients]);

    return(
      <div>
       
        <text className="recipe-text">Mango Sorbet</text>
        <p className="details-text">
      This refreshing mango sorbet is the perfect dessert. 
      </p>
      <div className='img-container'>
      <img className="img1" src="https://www.tasteofhome.com/wp-content/uploads/2019/10/Quick-Mango-Passion-Fruit-Sorbet_EXPS_TOHFM20_238674_B09_20_3b-4.jpg?fit=696,696" alt="Recipe 3"></img>
        </div>
        
      <div className='card-container'>
      <div className="card2">
      <p className="recipe-body-text">
        Ingredients
        </p>
      <p className="recipe-details-text">
      {ingredients.map((ingredient, index) => {
              return (
                <label key={index}>
                  <input type="checkbox" name={ingredient.name} onChange={handleCheckbox} />
                  <a href={`https://fdc.nal.usda.gov/fdc-app.html#/food-details/${ingredient.id}/nutrients`}>
                      {ingredient.fullName}
                    </a>
                  <br />
                  {ingredient.id}
                  <br />
                </label>
              );
            })}
      <button className="grocery-button" onClick={goToGroceryList}>Add to Grocery List</button> 
      </p>
      <p className="recipe-body-text">
        Directions
        <br />
      <button className="cooking-button" onClick = {togglePopup}> Cooking Mode</button>
      {isOpen && (
        <div className="popup">
          <button className="close-button" onClick={togglePopup}>X</button>
          <div> 
          <p className="popup-text">
          1. Place 16 oz frozen mango chunks, 1/2 cup passion fruit juice and 2 tablespoons sugar in a blender <br />
          <br />
          2. Cover and process until smooth. Serve immediately <br />
          <br />
          3. If desired, for a firmer texture, cover and freeze at least 3 hours.<br />
        </p>
          </div>
        </div>

      )}
      </p>
      <p className="recipe-details-text"> 
      1. Place all ingredients in a blender; cover and process until smooth. Serve immediately. If desired, for a firmer texture, cover and freeze at least 3 hours.<br />
      </p>
      </div>
      </div>
      
      </div>
    )
  }
